﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania_z_labów_6
{
    enum Kategoria
    {
        Japko,
        Skrzynka,
        Szafa
    }
    internal class Towar
    {
        public string nazwa;
        public int ilosc;
        public int cena;
        public Kategoria kategoria;

        public override string ToString()
        {
            return $"{nazwa} Ilosc:{ilosc} Cena:{cena} Kategoria:{kategoria}";
        }
    }
}
