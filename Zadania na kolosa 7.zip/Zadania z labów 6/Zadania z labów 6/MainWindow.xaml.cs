﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadania_z_labów_6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public static class Extensions
    {
        public static (T, T) MinMax<T, TKey>(this IEnumerable<T> collection, Func<T, TKey> keySelector)
        {
            if (!collection.Any())
            {
                throw new InvalidOperationException("Collection is empty.");
            }

            T min = collection.First();
            T max = collection.First();
            foreach (var item in collection.Skip(1))
            {
                if (Comparer<TKey>.Default.Compare(keySelector(item), keySelector(min)) < 0)
                {
                    min = item;
                }
                if (Comparer<TKey>.Default.Compare(keySelector(item), keySelector(max)) > 0)
                {
                    max = item;
                }
            }

            return (min, max);
        }
    }


    public partial class MainWindow : Window
    {

        private void Task1()
        {
            var task1Query = towars.Where(t => t.ilosc > 5).OrderByDescending(t => t.ilosc);
            foreach (var item in task1Query)
            {
                MessageBox.Show(item.ToString());
            }
        }

        private void Task2(Kategoria category)
        {
            var task2Query = towars.Count(t => t.kategoria == category);
            MessageBox.Show($"Number of products in category {category}: {task2Query}");
        }

        private void Task3()
        {
            var averagePrice = towars.Average(t => t.cena);
            var task3Query = towars.Where(t => t.cena > averagePrice).Select(t => new { t.nazwa, t.cena });
            foreach (var item in task3Query)
            {
                MessageBox.Show($"Name: {item.nazwa}, Price: {item.cena}");
            }
        }

        private void Task4()
        {
            var task4Query = towars.GroupBy(t => t.kategoria)
                                   .Select(g => new
                                   {
                                       Category = g.Key,
                                       Quantity = g.Sum(t => t.ilosc),
                                       AveragePrice = g.Average(t => t.cena)
                                   });
            foreach (var item in task4Query)
            {
                
                MessageBox.Show($"Category: {item.Category}, Quantity: {item.Quantity}, Average Price: {item.AveragePrice}");
            }
        }

        private void Task5()
        {
            var mostExpensive = towars.OrderByDescending(t => t.cena).FirstOrDefault();
            MessageBox.Show($"Most expensive product: {mostExpensive?.nazwa}, Price: {mostExpensive?.cena}");
        }

        List<Towar> towars = new List<Towar>() {
            new Towar(){nazwa="AAA", cena = 02, ilosc= 12, kategoria= Kategoria.Szafa},
            new Towar(){nazwa="dAA", cena = 92, ilosc= 22, kategoria= Kategoria.Szafa},
            new Towar(){nazwa="cAA", cena = 82, ilosc= 32, kategoria= Kategoria.Szafa},
            new Towar(){nazwa="A3A", cena = 72, ilosc= 42, kategoria= Kategoria.Skrzynka},
            new Towar(){nazwa="AaA", cena = 62, ilosc= 52, kategoria= Kategoria.Skrzynka},
            new Towar(){nazwa="AAA", cena = 52, ilosc= 62, kategoria= Kategoria.Skrzynka},
            new Towar(){nazwa="AAa", cena = 42, ilosc= 72, kategoria= Kategoria.Japko},
            new Towar(){nazwa="AaA", cena = 32, ilosc= 82, kategoria= Kategoria.Japko},
            new Towar(){nazwa="AAA", cena = 22, ilosc= 92, kategoria= Kategoria.Japko},
            new Towar(){nazwa="aAA", cena = 12, ilosc= 02, kategoria= Kategoria.Japko}
            };
        public MainWindow()
        {
            InitializeComponent();

            
        }

        Func<double, double, double> nowe = (x,y) => Math.Pow((1 - x),2) + 100* Math.Pow((y-Math.Pow(x,2)),2);

       
        private void btnFun1_Click(object sender, RoutedEventArgs e)
        {

           (double, double, double) wynik =  ZnajdzNajmniejsze.ZnajdźMinimumFunkcji2D(2, -2, -2, -2, nowe, 10000);
            lblWynik.Content= wynik.Item3;
            
        }

        private void btnTest2_Click(object sender, RoutedEventArgs e)
        {
            Task2(Kategoria.Japko);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Task1();
        }

        private void btnTest3_Click(object sender, RoutedEventArgs e)
        {
            Task3();
        }

        private void btnTest4_Click(object sender, RoutedEventArgs e)
        {
            Task4();
        }

        private void btnTest5_Click(object sender, RoutedEventArgs e)
        {
            //Task5();


            List<Towar> towary = new List<Towar>()
            {
            new Towar { nazwa = "Produkt1", ilosc = 10 },
            new Towar { nazwa = "Produkt2", ilosc = 5 },
            new Towar { nazwa = "Produkt3", ilosc = 20 }
            };

            var (minIlosc, maxIlosc) = towary.MinMax(t => t.ilosc);
            MessageBox.Show($"Zakres ilości: {minIlosc} - {maxIlosc}");
        }
    }
}
