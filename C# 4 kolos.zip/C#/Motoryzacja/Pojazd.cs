﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;


namespace Motoryzacja
{
    public class Pojazd
    {

        private List<RejestrNazw> historiaNazw = new List<RejestrNazw>();

        public List<RejestrNazw> HistoriaNazw
        {
            get { return historiaNazw; }
            set { historiaNazw = value; }
        }

        private string nazwa1;
        public string Nazwa { 
            get { return nazwa1; } 
            set {
                RejestrNazw nowy = new RejestrNazw();
                nowy.dataModyfikacji = DateTime.Now;
                nowy.nazwa = nazwa1;
                HistoriaNazw.Add(nowy);
                nazwa1 = value;
            } 
        }

        private int lp;

        public int Lp {
            get { return lp; } set { lp = value; } }


        private static int liczbaPojazdów = 0;
        public static int LiczbaPojazdów
        {
            get { return liczbaPojazdów; }
            set { liczbaPojazdów = value; }
        }


        private int kolo;
        public int Kola
        {
            get { return this.kolo; }
            private set { this.kolo = value; }
        }
        private int prendkosc;
        public int Prendkosc {
            get { return this.prendkosc; }
            private set { this.prendkosc = value; }
        }

        public Pojazd(string nazwa, int kola, int prendkosc) : this() {

            if (kola <= 0) throw new ArgumentOutOfRangeException();
            if (prendkosc <= 0) throw new ArgumentOutOfRangeException();


            Nazwa = nazwa;
            Kola = kola;
            Prendkosc = prendkosc;

        }

        public override string ToString() {


            return $"{lp}/{liczbaPojazdów} {Nazwa}- {Kola} kola, {Prendkosc} prędkości";
        }


        public Pojazd(string nazwa, int prendkosc) : this(nazwa, 4, prendkosc) {


        }

        public Pojazd()
        {
            liczbaPojazdów++;
            lp = liczbaPojazdów;
        }

        public void WyświetlHistorie( ref System.Windows.Controls.ListBox lista)
        {
            for(int i =0;  i<HistoriaNazw.Count; i++)
            {
                lista.Items.Add(HistoriaNazw[i].ToString());
            }
        }

    }

    public class PojazdMechaniczny : Pojazd{

        private int mocsilnika;
        public int Mocsilnika
        {
            get { return mocsilnika; }
            set { mocsilnika = value;}
        }

        public PojazdMechaniczny(int mocsilnika, int szybkosc, string nazwa): base(nazwa, szybkosc)
        {
            Mocsilnika = mocsilnika;
        }
    }

    public class Samochod : PojazdMechaniczny
    {
        private string marka;
        private int miejsce;
        public string Marka
        {
            get { return marka; }
            set { marka = value; }
        }


        private int Miejsce {

            get { return miejsce; }
            set { miejsce = value; }
        }

        public Samochod(string marka, int miejsce, int mocsilnika, int szybkosc, string nazwa): base(mocsilnika, szybkosc, nazwa)
        {
            
            Marka = marka;
            Miejsce = miejsce;
        }
    }

    public struct RejestrNazw
    {
        public DateTime dataModyfikacji;
        public String nazwa;

        public override string ToString()
        {
            return $"Data zmiany {dataModyfikacji}, Nazwa {nazwa}";
        }
    }

    

}