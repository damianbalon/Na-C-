﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Zajęcia_laboratoryjne_numer_7
{
    public class Student
    {
        [XmlElement("Nazwisko")]
        [JsonPropertyName("Nazwisko")]
        public string Nazwisko { get; set; }

        [XmlAttribute("Ocena")]
        [JsonPropertyName("Ocena")]
        public double Ocena { get; set; }
    }
}

