﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;

namespace Zajęcia_laboratoryjne_numer_7
{
    public partial class MainWindow : Window
    {
        private string baseDirectory;

        public MainWindow()
        {
            InitializeComponent();
            baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        }

        private void btnMelduj_Click(object sender, RoutedEventArgs e)
        {
            string filePath = Path.Combine(baseDirectory, "rejestr.txt");
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine(DateTime.Now.ToShortDateString());
            }
        }

        private void btnWyswietl_Click(object sender, RoutedEventArgs e)
        {
            lsbWynik.Items.Clear();
            List<double> list = new List<double>();
            string filePath = Path.Combine(baseDirectory, "dane.txt");
            using (StreamReader sr = new StreamReader(filePath))
            {
                while (sr.Peek() != -1)
                {
                    double wyczotane = Convert.ToDouble(sr.ReadLine());
                    lsbWynik.Items.Add(Convert.ToDouble(wyczotane.ToString("F3")));
                    list.Add(wyczotane);
                }
            }
            lbśrednia.Content = $"Srednia: {list.Average()} Minimalna: {list.Min()} Maxymalna: {list.Max()}";
        }

        private void btnSerializacja_Click(object sender, RoutedEventArgs e)
        {
            Grupa nowa = new Grupa()
            {
                Nazwa = "Jeden",
                Students = {
            new Student(){Ocena = 3, Nazwisko = "Nazwisko1"},
            new Student(){Ocena = 2, Nazwisko = "Nazwisko1"},
            new Student(){Ocena = 5, Nazwisko = "Nazwisko1"},
            new Student(){Ocena = 5, Nazwisko = "Nazwisko1"}
        }
            };

            string filePath = Path.Combine(baseDirectory, "grupa.xml");
            SerializeToXml(nowa, filePath);
            string filePathJson = Path.Combine(baseDirectory, "grupa.json");
            SerializeToJson(nowa, filePathJson);
        }

        private void SerializeToJson(Grupa obj, string filePath)
        {
            string json = JsonSerializer.Serialize<Grupa>(obj);
            File.WriteAllText(filePath, json);
        }


        private void SerializeToXml(object obj, string filePath)
        {
            XmlSerializer serializer = new XmlSerializer(obj.GetType());
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                serializer.Serialize(sw, obj);
            }
        }

        private void btnWyswietl1_Click(object sender, RoutedEventArgs e)
        {
            string filePath = Path.Combine(baseDirectory, "grupa.xml");

            Grupa grupa;
            using (StreamReader sr = new StreamReader(filePath))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Grupa));
                grupa = (Grupa)serializer.Deserialize(sr);
            }

            grupa.Wyświetl(lsbWynik);


            string filePathJson = Path.Combine(baseDirectory, "grupa.json");

            Grupa grupaFromJson;
            using (StreamReader sr = new StreamReader(filePathJson))
            {
                string json = sr.ReadToEnd();
                grupaFromJson = JsonSerializer.Deserialize<Grupa>(json);
            }

            grupaFromJson.Wyświetl(lsbWynik);
        }

        private void btnBIT_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "Bitmap Files|*.bmp";
            openFileDialog1.Title = "Select a BMP File";

            bool? result = openFileDialog1.ShowDialog();
            if (result == true)
            {
                string selectedFile = openFileDialog1.FileName;

                using (FileStream fileStream = new FileStream(selectedFile, FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(fileStream))
                    {
                        reader.BaseStream.Seek(18, SeekOrigin.Begin);

                        int width = reader.ReadInt32();
                        int height = reader.ReadInt32();
                        int bitCount = reader.ReadInt16();

                        lbśrednia.Content = "Width: " + width.ToString() + " Height: " + height.ToString() + " Bit Count: " + bitCount.ToString();

                        reader.BaseStream.Seek(10, SeekOrigin.Begin);
                        int dataOffset = reader.ReadInt32();

                        reader.BaseStream.Seek(dataOffset, SeekOrigin.Begin);
                        byte[] imageData = reader.ReadBytes((int)fileStream.Length - dataOffset);

                        MemoryStream memoryStream = new MemoryStream(imageData);
                        BitmapImage bmp = new BitmapImage();
                        bmp.BeginInit();
                        bmp.StreamSource = memoryStream;
                        bmp.EndInit();

                        pictureBox1.Source = bmp;
                    }
                }
            }
        }

    }





}
