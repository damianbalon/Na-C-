﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Windows.Controls;
using System.Xml.Serialization;

namespace Zajęcia_laboratoryjne_numer_7
{
    public class Grupa
    {
        [XmlElement("Nazwagrupy")]
        [JsonPropertyName("Nazwagrupy")]

        public string Nazwa { get; set; }

        [XmlElement("Student")]
        [JsonPropertyName("Student")]

        public List<Student> Students { get; set; } = new List<Student>();

        [XmlIgnore]
        [JsonIgnore]
        public int LiczbaStudentów => Students.Count;

        [XmlIgnore]
        [JsonIgnore]
        public double ŚredniaOcen
        {
            get
            {
                double srednia = 0;
                foreach (Student student in Students)
                {
                    srednia += student.Ocena;
                }
                return LiczbaStudentów > 0 ? srednia / LiczbaStudentów : 0;
            }
        }

        public void Wyświetl(ListBox listBox)
        {
            //listBox.Items.Clear();

            string dodanie = $"Grupa: {Nazwa} \n";

            foreach (Student student in Students)
            {
                dodanie += $"\t {student.Nazwisko} {student.Ocena} \n";
            }

            dodanie += $"Liczba studentów: {LiczbaStudentów}  \n" +
                       $"ŚredniaOcen: {ŚredniaOcen}";

            listBox.Items.Add(dodanie);
        }
    }
}
