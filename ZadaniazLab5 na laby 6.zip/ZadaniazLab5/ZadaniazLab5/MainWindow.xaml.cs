﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Generyki;

namespace ZadaniazLab5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


         void Info1(string text) { MessageBox.Show(text); }
         void Info2(string text) {

            lblWynik.Content= text;
            
        }
        private void btnWyswietl_Click(object sender, RoutedEventArgs e)
        {
            Stozek nowy = new Stozek();
            nowy.zdarzenie += Info1;
            nowy.Promien = Convert.ToInt32( txtPromien.Text);

            nowy.zdarzenie -= Info1;
            nowy.zdarzenie += Info2;
            nowy.Wysokosc = Convert.ToInt32(txtWysokosc.Text);

            lblWynik.Content = nowy.Objentosc();
        }

        private void btn_student_Click(object sender, RoutedEventArgs e)
        {
            Student jeden  = new Student() { Ocena = 2, Imie = "Arek" };
            Student dwa = new Student() { Ocena = 1, Imie = "Arek" };
            MessageBox.Show((Statyczna.ZnajdzWiekszy(jeden, dwa)).ToString());
        }

        private void btnRegal_Click(object sender, RoutedEventArgs e)
        {
            Student jeden = new Student() { Ocena = 2, Imie = "Arek" };
            Student dwa = new Student() { Ocena = 1, Imie = "Arek" };
            

           Regał<double> doblowy = new Regał<double>();
           Regał<Student> studentowy = new Regał<Student>();

            MessageBox.Show((doblowy.ToString()));
            doblowy.WstawNaWolnąPólke(2.3);
            doblowy.WstawNaWolnąPólke(3.2);
            MessageBox.Show((doblowy.ToString()));


            MessageBox.Show((studentowy.ToString()));
            studentowy.WstawNaWolnąPólke(jeden);
            studentowy.WstawNaWolnąPólke(dwa);
            MessageBox.Show((studentowy.ToString()));
        }
    }
}
