﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadaniazLab5
{
    public class Stozek
    {
        private int wysokosc;
        private int promien;
        public delegate void ObslugaBłedu(string opisBłedu);
        public event ObslugaBłedu zdarzenie;

        public int Wysokosc{

            get { return this.wysokosc; }
            set {

                if (value <= 0)
                {
                    zdarzenie("Zla wysokosc");
                    return;
                }

                if (zdarzenie == null)
                {
                    zdarzenie("Zla wysokosc");
                    return;
                }

                this.wysokosc = value;
            }
        }

        public int Promien
        {

            get { return this.promien; }
            set
            {

                if (value <= 0)
                {
                    zdarzenie("Zly promien");
                    return;
                }

                if (zdarzenie == null)
                {
                    zdarzenie("Zly promien");
                }

                this.promien = value;
            }
        }

        public string Objentosc()
        {
            return $"Objentosc wynosi: {1.0/3.0 * Math.PI * promien* promien * wysokosc}";
        }
    }
}
