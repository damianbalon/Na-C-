﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Generyki
{
     public class Regał<T>
    {
        public T Pulka1 { get; set; }
        public T Pulka2 { get; set; }
        public T Pulka3 { get; set; }
        
        public T WolnaPulka
        {
            get { 
                if (Pulka1 == null || Pulka1.Equals(default(T)))
                {
                    return Pulka1;

                }
                else if (Pulka2 == null || Pulka2.Equals(default(T)))
                {
                    return Pulka2;

                }
                else if (Pulka3 == null || Pulka3.Equals(default(T)))
                {
                    return Pulka3;
                }
                return default(T); }
        }

        public void WstawNaWolnąPólke(T obiekt)
        {
            if (Pulka1 == null || Pulka1.Equals(default(T)) )
            {
                Pulka1 = obiekt;

            }else if (Pulka2 == null || Pulka2.Equals(default(T))   )
            {
                Pulka2= obiekt;

            }else if (Pulka3 == null || Pulka3.Equals(default(T)))
            {
                Pulka3= obiekt;
            }
        }

        

        public override string ToString()
        {
            return $"Półka 1: {Pulka1}  Półka 2: {Pulka2}   Półka 3: {Pulka3}";
        }
    }
}
