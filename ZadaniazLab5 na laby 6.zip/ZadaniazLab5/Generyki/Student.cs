﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generyki
{
    public class Student : IComparable
    {
        public string Imie { get; set; }
        public int Ocena { get; set; }

        public int CompareTo(object jeden)
        {
            Student nowy = (Student)jeden;
            return this.Imie.CompareTo(nowy.Imie);
        }

        public override string ToString()
        {
            return $"{Imie}: {Ocena}";
        }
    }
}
