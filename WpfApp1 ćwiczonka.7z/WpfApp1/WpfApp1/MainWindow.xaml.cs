﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> list = new List<string>();
        public MainWindow()
        {
            InitializeComponent();

            
        }

        private void btnZglaszam_Click(object sender, RoutedEventArgs e)
        {
            list.Add(DateTime.Now.ToString());
        }

        private void btnWyswietl_Click(object sender, RoutedEventArgs e)
        {
            Wyswietl okno = new Wyswietl(list);
            okno.ShowDialog();
        }

        public void Wyswietl(decimal nowacena)
        {
            MessageBox.Show(nowacena.ToString());
        }

        public void WyswietlNowacena(decimal nowacena)
        {
            MessageBox.Show("Nowa cena");
        }

        public T JedenZTrzech<T>(T pierwsza, T druga, T trzecia)
        {

            Random rnd = new Random();

            int liczba = rnd.Next(0, 3);

            List<T> lista = new List<T>();
            lista.Add(pierwsza);
            lista.Add(druga);
            lista.Add(trzecia);
            return lista[liczba];
        }
        private void btnWyswietlSamolot_Click(object sender, RoutedEventArgs e)
        {
            decimal wyslane = 2;
            Samolot nowy = new Samolot();
            nowy.nowaCena += WyswietlNowacena;
            nowy.nowaCena += Wyswietl; 
            nowy.Cena = wyslane;
            nowy.nowaCena -= WyswietlNowacena;
            wyslane = 3;
            nowy.Cena = wyslane;
        }

        private void BtnWylosuj_Click(object sender, RoutedEventArgs e)
        {
            string jeden = "jeden";
            string dwa = "2";
            string trzy = "3";
            Class1 class1 = new Class1() { Id=1};
            Class1 class2 = new Class1() { Id = 2 };
            Class1 class3 = new Class1() { Id = 3 };

            MessageBox.Show(JedenZTrzech<string>(trzy, jeden, dwa));
            MessageBox.Show(JedenZTrzech<Class1>(class3, class2, class1).Id.ToString());
        }
    }
}
