﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class Samolot
    {
        public delegate void MetodaAlarm(decimal nowacena);
        public event MetodaAlarm nowaCena; 

        string nazwa;
        string Nazwa
        {
            get { return nazwa; }
            set { nazwa = value; }
        }

        decimal cena;
        public decimal Cena
        {
            get { return cena; }
            set { if (value != cena) { 
                    
                    cena = value;

                    nowaCena?.Invoke(value);

                }  
            }
        }

    }
}
