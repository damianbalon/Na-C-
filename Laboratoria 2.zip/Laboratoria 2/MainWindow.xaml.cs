﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Laboratoria_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public double Iloczyn(double first, double second)
        {
            return first * second; ;
        }

        public double Kwadrat(double bok)
        {

            return Iloczyn(bok,  bok);
        }

        public double Polekola(double promien)
        {
            return Iloczyn(Math.PI, Kwadrat(promien));
        }

        public double ObjętośćWalca(double bok, double promień)
        {
            return Iloczyn(Polekola(promień), bok);
        }

        public double ObjętośćWalca(double bok)
        {
            return ObjętośćWalca(bok, bok / 2);
        }

        private void btTest_Click(object sender, RoutedEventArgs e)
        {
            string tmp = "Iloczyn " + Iloczyn(2,2);
            lbWyniki.Items.Add(tmp);

             tmp = "Kwadrat " + Kwadrat( 2);
            lbWyniki.Items.Add(tmp);

             tmp = "Kolo " + Polekola( 2);
            lbWyniki.Items.Add(tmp);

             tmp = "Walec " + ObjętośćWalca(2, 2);
            lbWyniki.Items.Add(tmp);

             tmp = "Walce kwadratowy " + ObjętośćWalca(2);
            lbWyniki.Items.Add(tmp);


        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        public void Prostokąt(double wysokosc, double szerokosc, out double pole, out double obwód, out double przekantna)
        {
            pole= wysokosc*szerokosc;
            obwód = (wysokosc + szerokosc) * 2;
            przekantna = Math.Sqrt(wysokosc * wysokosc + szerokosc * szerokosc);
        }
        private void btTest3_Click(object sender, RoutedEventArgs e)
        {
            double pole;
            double obwód;
            double przekantna;
            Prostokąt(Convert.ToDouble(tbWysokosc.Text), Convert.ToDouble(tbWysokosc.Text), out pole, out obwód, out przekantna);
            MessageBox.Show("Pole " + pole + "\n" + "Obwód " + obwód + "\n" + "Przekątna " + przekantna);
        }

        private void btTest4_Click(object sender, RoutedEventArgs e)
        {
            int[,] array ={ { 20, 20,20, 145 }, { 160, 160, 20, 145 }, { 10, 170, 20, 20 }, { 20, 160, 60, 60 } };
            Color[] colors = { Colors.Green, Colors.Red, Colors.Black};
            //zdefiniować linie i wywoływać je w forze 
        }

        enum Season
        {
            Sum,
            Min,
            Max
        }

        private void btTest5_Click(object sender, RoutedEventArgs e, IEnumerable<int> numery, IEnumerable<int> numery, IEnumerable<int> numery)
        {
            lbWyniki.ClearValue;

            int[] numery = new ;

            if (rbSum.IsChecked == true)
            {
                MessageBoxResult messageBoxResult = MessageBox.Show(numery.Sum());
            }
            else if(rbMax.IsChecked == true)
            {

                MessageBoxResult messageBoxResult = MessageBox.Show(numery.Max());
            }
            else if(rbMin.IsChecked == true) 
            {
                MessageBoxResult messageBoxResult = MessageBox.Show(numery.Min());
            }

        }
    }

}
