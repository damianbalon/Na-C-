﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania_z_labów_6
{
    static internal class ZnajdzNajmniejsze
    {

        public static (double x, double y, double watosc) ZnajdźMinimumFunkcji2D(double maxX, double minX, double maxY, double minY, Func<double, double, double> funkcja, int liczbaiteraci)
        {
            double ?najx = null;
            double? najy = null;
            double? wwartosc = double.MaxValue;
            Random r = new Random();

            for (int i=0; i< liczbaiteraci; i++)
            {
                double losx = r.NextDouble() * (maxX - minX) + minX ;
                double losy = r.NextDouble() * (maxY - minY) + minY;

                double resoult = funkcja(losx, losy);

                if (resoult < wwartosc)
                {
                    najx = losx;
                    najy = losy;
                    wwartosc = resoult;
                }
            }



            (double, double, double) wynik;
            wynik.Item1 = (double)najx;
            wynik.Item2 = (double)najy;
            wynik.Item3 = (double)wwartosc;

            return wynik;
        }
    }
}
