﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadania_z_labów_6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Towar> towars = new List<Towar>() {
            new Towar(){nazwa="AAA", cena = 02, ilosc= 12, kategoria= Kategoria.Szafa},
            new Towar(){nazwa="dAA", cena = 92, ilosc= 22, kategoria= Kategoria.Szafa},
            new Towar(){nazwa="cAA", cena = 82, ilosc= 32, kategoria= Kategoria.Szafa},
            new Towar(){nazwa="A3A", cena = 72, ilosc= 42, kategoria= Kategoria.Skrzynka},
            new Towar(){nazwa="AaA", cena = 62, ilosc= 52, kategoria= Kategoria.Skrzynka},
            new Towar(){nazwa="AAA", cena = 52, ilosc= 62, kategoria= Kategoria.Skrzynka},
            new Towar(){nazwa="AAa", cena = 42, ilosc= 72, kategoria= Kategoria.Japko},
            new Towar(){nazwa="AaA", cena = 32, ilosc= 82, kategoria= Kategoria.Japko},
            new Towar(){nazwa="AAA", cena = 22, ilosc= 92, kategoria= Kategoria.Japko},
            new Towar(){nazwa="aAA", cena = 12, ilosc= 02, kategoria= Kategoria.Japko}
            };
        public MainWindow()
        {
            InitializeComponent();

            
        }

        Func<double, double, double> nowe = (x,y) => Math.Pow((1 - x),2) + 100* Math.Pow((y-Math.Pow(x,2)),2);

       
        private void btnFun1_Click(object sender, RoutedEventArgs e)
        {

           (double, double, double) wynik =  ZnajdzNajmniejsze.ZnajdźMinimumFunkcji2D(2, -2, -2, -2, nowe, 10000);
            lblWynik.Content= wynik.Item3;
            
        }
    }
}
