﻿using Microsoft.VisualBasic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void RysuujGwiazde(double sriodekX, double sriodekY, double wielkosc)
        {
            if (wielkosc < 5)
            {
                return;
            }

            Line myLine = new Line();
            myLine.X1 = sriodekX + wielkosc / 2.0;
            myLine.Y1 = sriodekY;
            myLine.X2 = sriodekX - wielkosc / 2.0;
            myLine.Y2 = sriodekY;
            myLine.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
            myLine.StrokeThickness = 4;



            cv_Rysuj.Children.Add(myLine);

            Line myLine2 = new Line();
            myLine2.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
            myLine2.X1 = sriodekX + (wielkosc / 2.0) / 2;
            myLine2.Y1 = sriodekY + (wielkosc / 2.0) * Math.Sqrt(3) / 2.0; ;
            myLine2.X2 = sriodekX - (wielkosc / 2.0) / 2;
            myLine2.Y2 = sriodekY - (wielkosc / 2.0) * Math.Sqrt(3) / 2.0;
            myLine2.StrokeThickness = 4;

            cv_Rysuj.Children.Add(myLine2);

            Line myLine3 = new Line();
            myLine3.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
            myLine3.X1 = sriodekX - (wielkosc / 2.0) / 2;
            myLine3.Y1 = sriodekY + (wielkosc / 2.0) * Math.Sqrt(3) / 2.0; ;
            myLine3.X2 = sriodekX + (wielkosc / 2.0) / 2;
            myLine3.Y2 = sriodekY - (wielkosc / 2.0) * Math.Sqrt(3) / 2.0;
            myLine3.StrokeThickness = 4;

            cv_Rysuj.Children.Add(myLine3);

            RysuujGwiazde(myLine.X1, myLine.Y1, wielkosc / 3.0);
            RysuujGwiazde(myLine2.X1, myLine2.Y1, wielkosc / 3.0);
            RysuujGwiazde(myLine3.X1, myLine3.Y1, wielkosc / 3.0);
            RysuujGwiazde(myLine.X2, myLine.Y2, wielkosc / 3.0);
            RysuujGwiazde(myLine2.X2, myLine2.Y2, wielkosc / 3.0);
            RysuujGwiazde(myLine3.X2, myLine3.Y2, wielkosc / 3.0);

        }

        private void Zamień(ref int A, ref int B)
        {
            int pom = A;
            A = B;
            B = pom;
        }

        private void btRysuj_Click(object sender, RoutedEventArgs e)
        {
            RysuujGwiazde(150, 150, 100);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int A = 50;
            int B = 40;
            Zamień(ref A, ref B);

            MessageBox.Show($"Wynik A = {A} Wynik B= {B}");
        }


        public void btTest3_Click(object sender, RoutedEventArgs e)
        {
            double[,] tablica = {
        { 1.1234, 2.3456, 3.5678 },
        { 2.0, 2.0, 3.0 },
        { 3.12345, 20.0, 3.0 },
        { 4.5678, 2.0, 3.0 },
        { 5.0, 2.0, 300.9876 }
    };

            for (int i = 0; i < 5; i++)
            {
                string formattedString = $"{tablica[i, 0].ToString("0.##").PadLeft(8)}, {tablica[i, 1].ToString("0.##").PadLeft(8)}, {tablica[i, 2].ToString("0.##").PadLeft(8)}, {(tablica[i, 0] + tablica[i, 1] + tablica[i, 2]).ToString("0.##").PadLeft(8)}";
                lsWynik.Items.Add(formattedString);
            }
        }
    }

}