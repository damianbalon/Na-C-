﻿using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadanie_z_kolosa_nr_8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnWczytaj__Click(object sender, RoutedEventArgs e)
        {
            lsbWyswietl.Items.Clear();
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "exe Files|*.exe";
            openFileDialog1.Title = "Select a exe File";
            bool? result = openFileDialog1.ShowDialog();
            if (result == true)
            {
                string selectedFile = openFileDialog1.FileName;

                using (FileStream fileStream = new FileStream(selectedFile, FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(fileStream))
                    {
                        /* reader.BaseStream.Seek(8, SeekOrigin.Begin);

                         for (int i = 0; i < 10; i++)
                         {
                             lsbWyswietl.Items.Add(reader.ReadInt16());
                         }*/

                        int dataOffset = reader.ReadInt32();

                        reader.BaseStream.Seek(dataOffset, SeekOrigin.Begin);
                        byte[] data = reader.ReadBytes(10);

                        lsbWyswietl.Items.Add(data.ToString());

                       //Nie che wyświetlać mi bajtów w tym plik u w taki sposób lecz kiedy je zmieniam na inta wyświetla mi wartości 
                    }
                }
            }
        }
    }
}
