﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Zadanie_na_laboratoriach_8
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
