﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace s2.EE_lab8.Models
{
    public partial class Student
    {
        public override string ToString()
        {
            return $"{Nazwisko} {Imię} {Wiek} {(Ocena?.ToString() ?? "Brak")}";
        }
    }
}
