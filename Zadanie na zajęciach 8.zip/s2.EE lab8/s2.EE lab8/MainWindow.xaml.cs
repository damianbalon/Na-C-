﻿using s2.EE_lab8.Models;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace s2.EE_lab8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnWyświel_Click(object sender, RoutedEventArgs e)
        {
            var db = new DbUczelnia();

            foreach (var Student in db.Studenci) {
                lsbWyswietl.Items.Add(Student);
            }
        }

        private void btnDodaj_Click(object sender, RoutedEventArgs e)
        {
            var db = new DbUczelnia();

            Student dodawany = new Student() {Imię = txtbImie.Text, Nazwisko = txtbNazwisko.Text, Ocena = Convert.ToDouble( txtbOcena.Text), Wiek = Convert.ToByte (txtbWiek.Text) };
            db.Add(dodawany);
            db.SaveChanges();
        }
    }
}