﻿using Microsoft.Data.SqlClient;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zadanie_z_labow_9_cz2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void lsbWyswietl_Click(object sender, RoutedEventArgs e)
        {
            using (var połączenie = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Uczelnia;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False"))
            {

                połączenie.Open();
                SqlCommand polecenie = new SqlCommand("EXEC dbo.sp_GetStudents", połączenie);
                SqlDataReader reader = await polecenie.ExecuteReaderAsync();
                while (reader.Read())
                {
                    lsbwyswietl.Items.Add(reader["Name"].ToString());
                }

                połączenie.Close();
            }
        }
    }
}