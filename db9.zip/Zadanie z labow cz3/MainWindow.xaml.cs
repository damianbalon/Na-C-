﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadanie_z_labow_cz3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        (double, double, double) MinimalizujFunkcję(double minx, double maxX, double miny, double maxY, int ileIteacji, Func<double, double, double> funkcja)
        {
            double? najX = null, najY= null, najWart = null;
            Random los = new Random();


            for (int i = 0; i < ileIteacji; i++)
            {
                double x = los.NextDouble() * (maxX-minx)+minx;
                double y = los.NextDouble() * (maxY - miny) + miny;
                double wynik = funkcja(x, y);

                if(najWart == null || najWart > wynik)
                {
                    najX = x;
                    najY = y;
                    najWart = wynik;
                }
            }

            return ((double)najX, (double)najY, (double)najWart);
        }
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}