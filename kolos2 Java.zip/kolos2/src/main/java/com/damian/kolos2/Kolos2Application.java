package com.damian.kolos2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kolos2Application {

	public static void main(String[] args) {
		SpringApplication.run(Kolos2Application.class, args);
	}

}
