package com.damian.kolos2.repository;


import com.damian.kolos2.model.Kwiatek;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KwiatekRepository extends JpaRepository<Kwiatek, Long> {
}
