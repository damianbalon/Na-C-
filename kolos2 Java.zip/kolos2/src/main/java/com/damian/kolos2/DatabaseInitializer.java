package com.damian.kolos2;

import com.damian.kolos2.model.Kwiatek;
import com.damian.kolos2.repository.KwiatekRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DatabaseInitializer implements CommandLineRunner {

    private final KwiatekRepository kwiatekRepository;

    @Autowired
    public DatabaseInitializer(KwiatekRepository kwiatekRepository) {
        this.kwiatekRepository = kwiatekRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        for (int i = 1; i <= 10; i++) {
            Kwiatek kwiatek = new Kwiatek("Kwiatek " + i, Math.random() * 10);
            kwiatekRepository.save(kwiatek);
        }
    }
}

