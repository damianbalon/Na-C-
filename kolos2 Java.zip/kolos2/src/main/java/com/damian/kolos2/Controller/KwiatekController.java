package com.damian.kolos2.Controller;

import com.damian.kolos2.model.Kwiatek;
import com.damian.kolos2.repository.KwiatekRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class KwiatekController {

    private final KwiatekRepository kwiatekRepository;
    private final ObjectMapper objectMapper;

    @Autowired
    public KwiatekController(KwiatekRepository kwiatekRepository, ObjectMapper objectMapper) {
        this.kwiatekRepository = kwiatekRepository;
        this.objectMapper = objectMapper;
    }

    @GetMapping("/")
    public ResponseEntity<String> getAllKwiatki() throws Exception {
        List<Kwiatek> kwiatki = kwiatekRepository.findAll();
        String json = objectMapper.writeValueAsString(kwiatki);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new ResponseEntity<>(json, headers, HttpStatus.OK);
    }
}







