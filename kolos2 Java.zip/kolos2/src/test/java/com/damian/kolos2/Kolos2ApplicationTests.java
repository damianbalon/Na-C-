package com.damian.kolos2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kolos2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
