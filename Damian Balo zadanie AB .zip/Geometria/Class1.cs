﻿namespace Geometria
{
    abstract public class Bryla
    {
        String nazwa;
        double gestosc;
        double cenaZaKilogram;

        public String Nazwa
        {
            get { return nazwa; }
        }

        public double Genstosc
        {
            get { return gestosc; }
        }

        public double CenaZaKilogram
        {
            get { return cenaZaKilogram;}
        }

        abstract public double ObliczObjentosc();

        public double ObliczMase()
        {
            return ObliczObjentosc() * gestosc; 
        }

        public double ObliczCene()
        {
            return ObliczMase() * cenaZaKilogram;
        }

        public Bryla(string nazwa, double gestosc, double cenaZaKilogram)
        {
            this.nazwa = nazwa;
            this.gestosc = gestosc;
            this.cenaZaKilogram = cenaZaKilogram;
        }

        public override string ToString()
        {
            return $"{Nazwa} ma gęstość na poziomie {Genstosc} oraz cena za kilo na poziomie {CenaZaKilogram}";
        }
    }

    public class Kula : Bryla
    {
        double promien;

        public double Promien
        {
            get { return promien; }
        }

        public override double ObliczObjentosc() { 
            return 4.0/3.0 * Math.PI * Math.Pow(promien,3);
        }

        public Kula(double promien, string nazwa, double gestosc, double cenaZaKilogram) : base( nazwa,  gestosc,  cenaZaKilogram)
        { this.promien = promien; }
    }

    public class Stozek:Bryla
    {
        double promien;
        double wysokosc;

        public double Promien
        {
            get { return promien; }
        }

        public double Wysokosc
        {
            get { return wysokosc; }
        }

        public Stozek(double promien, double wysokosc, string nazwa, double gestosc, double cenaZaKilogram) : base(nazwa, gestosc, cenaZaKilogram)
        { this.promien = promien;
            this.wysokosc = wysokosc;
        }
        public override double ObliczObjentosc()
        {
            return 1.0 / 3.0 * Math.PI * Math.Pow(promien, 2) * Wysokosc;
        }
    }
}