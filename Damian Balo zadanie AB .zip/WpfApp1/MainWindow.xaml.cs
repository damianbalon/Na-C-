﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Geometria;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Geometria.Kula nowa = new Kula(4, "nowa", 3, 3);

            MessageBox.Show(nowa.ToString());
            MessageBox.Show(nowa.ObliczCene().ToString());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var okno = new DaneWejsciowe();
            okno.ShowDialog();
            double h, w, P;

            w = okno.Szerokosc;
            h = okno.Wysokosc;
            P = w * h;

            var oknoWy = new DaneWyjsciowe(P);
            oknoWy.ShowDialog();
        }
    }
}
