﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Logika interakcji dla klasy DaneWejsciowe.xaml
    /// </summary>
    public partial class DaneWejsciowe : Window
    {
        public DaneWejsciowe()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public double Wysokosc
        {
            get { return Convert.ToDouble(txtWysokosc.Text); }
        }
        public double Szerokosc
        {
            get { return Convert.ToDouble(txtSzerokosc.Text); }
        }


    }
}
