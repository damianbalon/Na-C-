﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generyki
{
    public class Student : IComparable
    {
        string imie;

        public int CompareTo(object jeden)
        {
            Student nowy = (Student)jeden;
            return this.imie.CompareTo(nowy.imie);
        }
    }
}
