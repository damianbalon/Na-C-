﻿namespace Generyki
{
    public class Class1
    {

    }
}