﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generyki
{
     internal class Regał<T>
    {
        public T Pulka1 { get; set; }
        public T Pulka2 { get; set; }
        public T Pulka3 { get; set; }
    
        public void WstawNaWolnąPólke(T obiekt)
        {
            if (Pulka1.Equals(default(T)) || Pulka1 == null)
            {
                Pulka1 = obiekt;

            }else if (Pulka2.Equals(default(T)) || Pulka1 == null)
            {
                Pulka2= obiekt;

            }else if (Pulka3.Equals(default(T)) || Pulka1 == null)
            {
                Pulka3= obiekt;
            }
        }

        public override string ToString()
        {
            return $"Półka 1: {Pulka1}  Półka 2: {Pulka2}   Półka 3: {Pulka3}";
        }
    }
}
