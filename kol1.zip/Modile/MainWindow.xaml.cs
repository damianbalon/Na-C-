﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Motoryzacja;

namespace Modile
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btZadanieA_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Pojazd testowopusty = new Pojazd();
                Pojazd[] tablicapojazdów = {
            new Pojazd("Wolwo 1", 5, 5), new Pojazd("Chonda 1", 2), new Pojazd("Szkoda 1", 5, 7)
                };

                for (int i = 0; tablicapojazdów.Length > i; i++)
                {
                    lsbZadA.Items.Add(tablicapojazdów[i]);
                }
            }
            catch
            {
                MessageBox.Show("BŁĄD");
            }
        }
    }
}
