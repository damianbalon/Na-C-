﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Zadanie_z_labow_9.Migrations
{
    /// <inheritdoc />
    public partial class Inicjalizacja : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
