using Zadanie_z_lab�w_9.DAL;
using Zadanie_z_labow_9.Model;
using Zadanie_z_labow_9.ViewModels;

namespace TestProject1
{
    public class UnitTest1
    {
        class StudentRepositoryFake : IStudentRepository
        {
            public void AddStudent(Student student)
            {
                throw new NotImplementedException();
            }

            public Student Get(int id)
            {
                throw new NotImplementedException();
            }

            public List<Student> GetAll()
            {
                return new List<Student> { new Student() { Name = "kowal" }, new Student { Name = "nowy" } };
            }

            public void RemoveStudent(int id)
            {
                throw new NotImplementedException();
            }

            public void UpdateStudent(Student student)
            {
                throw new NotImplementedException();
            }
        }

        [Fact]
        public void Test1()
        {
            var svm = new StudentRepositoryFake();

            svm.GetAll();

            Assert.Equal(2, );
        }
    }
}