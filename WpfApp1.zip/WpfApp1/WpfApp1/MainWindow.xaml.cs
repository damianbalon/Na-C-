﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Schema;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btPiramida_Click(object sender, RoutedEventArgs e)
        {
            Ellipse myRectangle = new Ellipse();


            myRectangle.Width = 100;
            myRectangle.Height = 50;
            myRectangle.Stroke = System.Windows.Media.Brushes.LightSteelBlue;

            Canvas.SetLeft(myRectangle, 100);
            Canvas.SetTop(myRectangle, 150);

            cvRysunek.Visibility = Visibility.Visible;
            cvRysunek.Children.Add(myRectangle);

            mdGrid.Visibility = Visibility.Visible;

            int i = 0;
            int j = 0;

            int gridSize = mdGrid.RowDefinitions.Count;

            
            for (int row = 0; row < gridSize; row++)
            {
                for (int column = 0; column < gridSize; column++)
                {
                    Rectangle rect = new Rectangle();
                    rect.Width = 50;
                    rect.Height = 50;

                    if ((row + column) % 2 == 0) 
                        rect.Fill = Brushes.White; 
                    else
                        rect.Fill = Brushes.Black; 

                    Grid.SetRow(rect, row); // ustawiamy wiersz prostokąta
                    Grid.SetColumn(rect, column); // ustawiamy kolumnę prostokąta
                    mdGrid.Children.Add(rect); // dodajemy prostokąt do siatki (grid)
                }

            }
        }

            private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(q1.IsChecked == true && q2.SelectedIndex == 0 && q3.IsChecked == true)
            {
       
                q1a.Text = "Zdales";
            }
        }
    }
}