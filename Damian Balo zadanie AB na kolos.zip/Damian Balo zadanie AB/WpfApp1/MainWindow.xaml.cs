﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Geometria;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //Geometria.Kula nowa = new Kula(4, "nowa", 3, 3);

            //MessageBox.Show(nowa.ToString());
            //MessageBox.Show(nowa.ObliczCene().ToString());

            List<IWyświetl> listaObiektów = new List<IWyświetl>();
            listaObiektów.Add(new Kula(3, "Kula 1", 3, 3));
            listaObiektów.Add(new Kula(4, "Kula 2", 3, 4));
            listaObiektów.Add(new Student { Imię = "John", Nazwisko = "Doe" });
            listaObiektów.Add(new Stozek(6, 2, "Stozek", 2, 2));
            listaObiektów.Add(new Student { Imię = "Jane", Nazwisko = "Doe" });
            listaObiektów.Add(new Student { Imię = "Alice", Nazwisko = "Smith" });

            listaObiektów.Sort();

            foreach (var item in listaObiektów)
            {
                lsbWyniowy.Dodaj(item);
            }

        }




        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var okno = new DaneWejsciowe();
            okno.ShowDialog();
            double h, w, P;

            w = okno.Szerokosc;
            h = okno.Wysokosc;
            P = w * h;

            var oknoWy = new DaneWyjsciowe(P);
            oknoWy.ShowDialog();
        }
    }
}
