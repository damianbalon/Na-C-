﻿namespace Geometria
{
    abstract public class Bryla : IWyświetl
    {
        String nazwa;
        double gestosc;
        double cenaZaKilogram;

        public String Nazwa
        {
            get { return nazwa; }
        }

        public double Genstosc
        {
            get { return gestosc; }
        }

        public double CenaZaKilogram
        {
            get { return cenaZaKilogram;}
        }

        abstract public double ObliczObjentosc();

        public double ObliczMase()
        {
            return ObliczObjentosc() * gestosc; 
        }

        public double ObliczCene()
        {
            return ObliczMase() * cenaZaKilogram;
        }

        public Bryla(string nazwa, double gestosc, double cenaZaKilogram)
        {
            this.nazwa = nazwa;
            this.gestosc = gestosc;
            this.cenaZaKilogram = cenaZaKilogram;
        }

        public override string ToString()
        {
            return $"{Nazwa} ma gęstość na poziomie {Genstosc} oraz cena za kilo na poziomie {CenaZaKilogram}";
        }

        abstract public string PobierzIdentyfikator();


        public int CompareTo(object? obj)
        {
            if (obj is Student)
            {
                return 1;
            }
            Bryla bryl = (Bryla)obj;

            return this.ObliczObjentosc().CompareTo(bryl.ObliczObjentosc());
        }
    }

    public class Kula : Bryla
    {
        double promien;

        public double Promien
        {
            get { return promien; }
        }

        public override double ObliczObjentosc() { 
            return 4.0/3.0 * Math.PI * Math.Pow(promien,3);
        }

        public Kula(double promien, string nazwa, double gestosc, double cenaZaKilogram) : base( nazwa,  gestosc,  cenaZaKilogram)
        { this.promien = promien; }

        override public string PobierzIdentyfikator()
        {
            return $"Kula {ObliczObjentosc()}";
        }

    }

    public class Stozek:Bryla
    {
        double promien;
        double wysokosc;

        public double Promien
        {
            get { return promien; }
        }

        public double Wysokosc 
        {
            get { return wysokosc; }
        }

        public Stozek(double promien, double wysokosc, string nazwa, double gestosc, double cenaZaKilogram) : base(nazwa, gestosc, cenaZaKilogram)
        { this.promien = promien;
            this.wysokosc = wysokosc;
        }
        public override double ObliczObjentosc()
        {
            return 1.0 / 3.0 * Math.PI * Math.Pow(promien, 2) * Wysokosc;
        }

        override public string PobierzIdentyfikator()
        {
            return $"Stożek: {ObliczObjentosc()}";
        }


    }

    public class Student : IWyświetl
    {
        public string Imię { get; set; }
        public string Nazwisko { get; set; }

        public string PobierzIdentyfikator()
        {
            return $"{Imię} {Nazwisko}";
        }

        public int CompareTo(object? obj)
        {
            if(obj is Bryla)
            {
                return -1;
            }
            Student st = (Student)obj;

            return this.Nazwisko.CompareTo(st.Nazwisko);
        }


    }


    public static class ListBoxExtensions
    {
        public static void Dodaj(this System.Windows.Controls.ListBox listBox, IWyświetl item)
        {
            listBox.Items.Add(item.PobierzIdentyfikator());
        }
    }

    public interface IWyświetl: IComparable
    {
        string PobierzIdentyfikator();
    }
}