﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Xml;
using System.Xml.Serialization;

namespace Zajęcia_laboratoryjne_numer_7
{
    public class Grupa
    {
        [XmlElement("Nazwagrupy")]
        public string Nazwa { get; set; }

        
        public List<Student> Students { get; set; } = new List<Student>() ;
        
        int LiczbaStudentów { get {

                return Students.Count(); 
            } }
        double ŚredniaOcen { get {
                double srednia = 0;
                foreach (Student student in Students)
                {
                    srednia += student.Ocena;
                }
                srednia = srednia / LiczbaStudentów;

                return srednia; }
        }

        public void Wyświetl(ListBox listBox)
        {
            listBox.Items.Clear();

            string dodanie = $"Grupa: {Nazwa} \n";

            foreach (Student student in Students) {

                dodanie += $"\t {student.Nazwisko} {student.Ocena} \n";
            }

            dodanie += $"Liczba studentów: {LiczbaStudentów}  \n" +
                $"ŚredniaOcen: {ŚredniaOcen}";

            listBox.Items.Add(dodanie);
        } 
    }
}
