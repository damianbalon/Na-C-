﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Zajęcia_laboratoryjne_numer_7
{
    public class Student
    {
        [XmlElement("Nazwisko")]
        public string Nazwisko;
        [XmlAttribute]
        public double Ocena;
    }
}
