﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Zajęcia_laboratoryjne_numer_7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        private void btnMelduj_Click(object sender, RoutedEventArgs e)
        {
            FileStream fs = new FileStream("C:\\Users\\Student\\Desktop\\kk_16.04\\Zajęcia laboratoryjne numer 7\\rejestr.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(DateTime.Now.ToShortDateString());
            sw.Close();
        }

        private void btnWyswietl_Click(object sender, RoutedEventArgs e)
        {
            lsbWynik.Items.Clear();
            List<double> list = new List<double>();
            StreamReader sr = new StreamReader("C:\\Users\\Student\\Desktop\\kk_16.04\\Zajęcia laboratoryjne numer 7\\dane.txt");
            while(sr.Peek() != -1)
            {
                double wyczotane = Convert.ToDouble(sr.ReadLine());
                lsbWynik.Items.Add(Convert.ToDouble(wyczotane.ToString("F3")));
                list.Add(wyczotane);
            };
            lbśrednia.Content = $"Srednia: {list.Average()} Minimalna: {list.Min()} Maxymalna: {list.Max()}";
            sr.Close();
        }

        private void btnSerializacja_Click(object sender, RoutedEventArgs e)
        {
            Grupa nowa = new Grupa()
            {
                Nazwa = "Jeden",
                Students = {
                new Student(){Ocena = 3, Nazwisko = "Nazwisko1"},
                new Student(){Ocena = 2, Nazwisko = "Nazwisko1"},
                new Student(){Ocena = 5, Nazwisko = "Nazwisko1"},
                new Student(){Ocena = 5, Nazwisko = "Nazwisko1"}
                }
            };

            FileStream fs = new FileStream("C:\\Users\\Student\\Desktop\\kk_16.04\\Zajęcia laboratoryjne numer 7\\grupa.xml", FileMode.Create);
            nowa.Wyświetl(lsbWynik);
            XmlSerializer ser = new XmlSerializer(typeof(Grupa));
            ser.Serialize(fs, nowa);
        }
    }
}
